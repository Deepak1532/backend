const User=require('../model/User')
const Jwt=require('jsonwebtoken')//for login authentication

const expressJWT=require('express-jwt') 


exports.postUser=(req,res)=>{
    let user=new User(req.body)
    user.save((error,user)=>{
        if(error){
            return res.status(400).json({
                error:'something went wrong'
            })
        }
        res.json({user})
    })
}


exports.signIn=(req,res)=>{
    const {email,password}=req.body
    User.findOne({email},(error,user)=>{
        if(error||!user){
            res.status(400).json({
                error:'user with that email doesnot exist'
            })
        }
        if(!user.authenticate(password)){
            res.status(400).json({error:'Email or password doesnot match'})
        }

        //genetaing token by combing user id and jwt_sectet
    const token=Jwt.sign({_id:user._id},process.env.JWT_SECRET) 

        res.cookie('ab',token,{expire:new Date()+9999})
        
        const {_id,role,email}=user
        res.json({token,user:{_id,role,email}})
    })
}

exports.signOut=(req,res)=>{
    res.clearCookie('ab')
    res.json({message:'Signout successful'})
}