const Product=require('../model/product');
const User = require('../model/User');
// to read the data from database
exports.read=(req,res)=>{
    Product.find().sort({createdAt:-1})
    .then(result=>{
        res.json({result})

    })
    .catch(err=>{
        console.log(err)
    })
}

//to read the single data
exports.singleProduct=(req,res)=>{
    const id=req.params.id
    Product.findById(id)
    .then(result=>{
        res.json({result})

    })
    .catch(err=>{
        console.log(err)
    })
}

//to update the data
exports.toUpdate=(req,res)=>{
    const id=req.params.id
    Product.findByIdAndUpdate(id,req.body)
    .then(result=>{
        res.json({result})

    })
    .catch(err=>{
        console.log(err)
    })
}
//to create data 
exports.postproduct=(req,res)=>{
    const product=new Product(req.body);
    Product.findOne({product_name:product.product_name},(err,data)=>{
        if(data==null)
        {
            product.save()
            .then(item=>{
                res.send("item saved to database");
            })
            .catch(err=>{
                res.status(400).send("unable to save to database");
            });
        }
        else{
            res.status(400).json({msg:'Product must be unique'})
        }
       
    })
    
}

