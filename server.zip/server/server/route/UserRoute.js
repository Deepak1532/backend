const express=require('express')
const { postUser, signIn, signOut } = require('../controller/UserController')
const router=express.Router()

router.post('/postuser',postUser)
router.post('/signin',signIn)
router.get('/signout',signOut)

module.exports=router