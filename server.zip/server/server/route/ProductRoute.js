const express=require('express');
const router=express.Router();
const {postproduct,read, singleProduct, toUpdate}=require('../controller/ProductController');
const {productValidation}=require('../validation/Index')
const user=require('../model/User')

router.post('/postProduct',productValidation,postproduct);
router.get('/getproduct',read)
router.patch('/patchproduct/:id',toUpdate)
router.get('/getproduct/:id',singleProduct)
module.exports=router;